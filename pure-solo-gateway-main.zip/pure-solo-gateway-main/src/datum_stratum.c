/*
 * Pure Solo Gateway
 * Stratum V1 server
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdint.h>
#include <errno.h>
#include <jansson.h>
#include <inttypes.h>
#include <sys/resource.h>
#include <math.h>

#include "datum_gateway.h"
#include "datum_stratum.h"
#include "datum_stratum_dupes.h"
#include "datum_jsonrpc.h"
#include "datum_utils.h"
#include "datum_blocktemplates.h"
#include "datum_sockets.h"
#include "datum_conf.h"
#include "datum_coinbaser.h"
#include "datum_submitblock.h"

T_DATUM_SOCKET_APP *global_stratum_app = NULL;

int stratum_job_next = 0;
T_DATUM_STRATUM_JOB stratum_job_list[MAX_STRATUM_JOBS];

int global_latest_stratum_job_index = -1;
T_DATUM_STRATUM_JOB *global_cur_stratum_jobs[MAX_STRATUM_JOBS] = { 0 };

pthread_rwlock_t stratum_global_job_ptr_lock = PTHREAD_RWLOCK_INITIALIZER;
uint16_t stratum_enprefix = 0;

pthread_rwlock_t stratum_global_latest_empty_stat = PTHREAD_RWLOCK_INITIALIZER;
uint64_t stratum_latest_empty_complete_count = 0;
bool stratum_latest_empty_ready_for_full = 0;
uint64_t stratum_latest_empty_job_index = 0;
uint64_t stratum_latest_empty_sent_count = 0;

pthread_rwlock_t need_coinbaser_rwlocks[MAX_STRATUM_JOBS];
bool need_coinbaser_rwlocks_init_done = false;

void stratum_latest_empty_increment_complete(uint64_t index, int clients_notified) {
	pthread_rwlock_wrlock(&stratum_global_latest_empty_stat);
	if ((stratum_latest_empty_job_index == index) && (!stratum_latest_empty_ready_for_full)) {
		stratum_latest_empty_complete_count++;
		stratum_latest_empty_sent_count += clients_notified;
	}
	pthread_rwlock_unlock(&stratum_global_latest_empty_stat);
}

bool stratum_latest_empty_check_ready_for_full(void) {
	bool a = false;
	pthread_rwlock_rdlock(&stratum_global_latest_empty_stat);
	if (stratum_latest_empty_ready_for_full) {
		a = true;
	}
	pthread_rwlock_unlock(&stratum_global_latest_empty_stat);
	return a;
}

void datum_stratum_v1_shutdown_all(void) {
	int ret;
	unsigned int shutdown_threads = 0;
	if (!global_stratum_app) return;
	
	for (int tid = 0; tid < global_stratum_app->max_threads; ++tid) {
		if (!global_stratum_app->datum_threads[tid].is_active) continue;
		ret = pthread_mutex_lock(&global_stratum_app->datum_threads[tid].thread_data_lock);
		if (ret != 0) {
			DLOG_FATAL("Could not lock mutex for thread data on TID %d: %s", tid, strerror(ret));
			panic_from_thread(__LINE__); 
			return;
		}
		global_stratum_app->datum_threads[tid].empty_request = true;
		shutdown_threads++;
		pthread_mutex_unlock(&global_stratum_app->datum_threads[tid].thread_data_lock);
	}
	DLOG_INFO("Sent disconnect request for all stratum clients to %u threads.", shutdown_threads);
	return;
}

void *datum_stratum_v1_socket_server(void *arg) {
	T_DATUM_SOCKET_APP *app;
	pthread_t pthread_datum_stratum_socket_server;
	int ret, i, j;
	uint64_t ram_allocated = 0;
	
	DLOG_DEBUG("Stratum V1 server startup");
	app = (T_DATUM_SOCKET_APP *)calloc(1,sizeof(T_DATUM_SOCKET_APP));
	if (!app) {
		panic_from_thread(__LINE__);
		return NULL;
	}
	ram_allocated += sizeof(T_DATUM_SOCKET_APP);
	
	strcpy(app->name, "Solo Stratum V1");
	
	app->init_func = datum_stratum_v1_socket_thread_init;
	app->loop_func = datum_stratum_v1_socket_thread_loop;
	app->client_cmd_func = datum_stratum_v1_socket_thread_client_cmd;
	app->closed_client_func = datum_stratum_v1_socket_thread_client_closed;
	app->new_client_func = datum_stratum_v1_socket_thread_client_new;
	
	app->listen_port = datum_config.stratum_v1_listen_port;
	app->max_clients_thread = datum_config.stratum_v1_max_clients_per_thread;
	app->max_threads = datum_config.stratum_v1_max_threads;
	app->max_clients = datum_config.stratum_v1_max_clients;
	
	app->datum_threads = (T_DATUM_THREAD_DATA *) calloc(app->max_threads + 1, sizeof(T_DATUM_THREAD_DATA));
	ram_allocated += (sizeof(T_DATUM_THREAD_DATA) * (app->max_threads + 1));
	
	app->datum_threads[0].app_thread_data = calloc(app->max_threads + 1, sizeof(T_DATUM_STRATUM_THREADPOOL_DATA));
	for(i=1;i<app->max_threads;i++) {
		app->datum_threads[i].app_thread_data = &((char *)app->datum_threads[0].app_thread_data)[sizeof(T_DATUM_STRATUM_THREADPOOL_DATA)*i];
	}
	ram_allocated += (sizeof(T_DATUM_STRATUM_THREADPOOL_DATA) * (app->max_threads + 1));
	
	app->datum_threads[0].client_data[0].app_client_data = calloc(((app->max_threads*app->max_clients_thread)+1), sizeof(T_DATUM_MINER_DATA));
	ram_allocated += ((app->max_threads*app->max_clients_thread)+1) * sizeof(T_DATUM_MINER_DATA);
	
	for(i=0;i<app->max_threads;i++) {
		for(j=0;j<app->max_clients_thread;j++) {
			if (!((i == 0) && (j == 0))) {
				app->datum_threads[i].client_data[j].app_client_data = &((char *)app->datum_threads[0].client_data[0].app_client_data)[((i*app->max_clients_thread)+j) * sizeof(T_DATUM_MINER_DATA)];
			}
		}
	}
	
	for (i = 0; i < MAX_STRATUM_JOBS; i++) {
		pthread_rwlock_init(&need_coinbaser_rwlocks[i], NULL);
	}
	need_coinbaser_rwlocks_init_done = true;
	
	DLOG_DEBUG("Starting submitblock thread");
	datum_submitblock_init();
	
	pthread_rwlock_rdlock(&stratum_global_job_ptr_lock);
	i = global_latest_stratum_job_index;
	pthread_rwlock_unlock(&stratum_global_job_ptr_lock);
	
	if (i < 0) {
		DLOG_DEBUG("Waiting for our first job before starting listening server...");
		j = 0;
		i = global_latest_stratum_job_index;
		while(i<0) {
			usleep(50000);
			pthread_rwlock_rdlock(&stratum_global_job_ptr_lock);
			i = global_latest_stratum_job_index;
			pthread_rwlock_unlock(&stratum_global_job_ptr_lock);
			j++;
		}
	}
	
	DLOG_DEBUG("Starting listener thread %p",app);
	ret = pthread_create(&pthread_datum_stratum_socket_server, NULL, datum_gateway_listener_thread, app);
	if (ret != 0) {
		DLOG_FATAL("Could not pthread_create for socket listener!: %s", strerror(ret));
		panic_from_thread(__LINE__);
		return NULL;
	}
	
	global_stratum_app = app;
	
	while (1) {
		pthread_rwlock_wrlock(&stratum_global_latest_empty_stat);
		if (!stratum_latest_empty_ready_for_full) {
			if (stratum_latest_empty_complete_count >= app->datum_active_threads) {
				stratum_latest_empty_ready_for_full = true;
			}
		}
		pthread_rwlock_unlock(&stratum_global_latest_empty_stat);
		usleep(11000);
	}
	return NULL;
}

int datum_stratum_v1_global_subscriber_count(void) {
	int j, kk, ii;
	T_DATUM_MINER_DATA *m;
	if (!global_stratum_app) return 0;
	kk = 0;
	for(j=0;j<global_stratum_app->max_threads;j++) {
		for(ii=0;ii<global_stratum_app->max_clients_thread;ii++) {
			if (global_stratum_app->datum_threads[j].client_data[ii].fd > 0) {
				m = global_stratum_app->datum_threads[j].client_data[ii].app_client_data;
				if (m->subscribed) kk++;
			}
		}
	}
	return kk;
}

double datum_stratum_v1_est_total_th_sec(void) {
	double hr;
	unsigned char astat;
	double thr = 0.0;
	T_DATUM_MINER_DATA *m = NULL;
	uint64_t tsms;
	int j,ii;
	if (!global_stratum_app) return 0;
	tsms = current_time_millis();
	for(j=0;j<global_stratum_app->max_threads;j++) {
		for(ii=0;ii<global_stratum_app->max_clients_thread;ii++) {
			if (global_stratum_app->datum_threads[j].client_data[ii].fd > 0) {
				m = global_stratum_app->datum_threads[j].client_data[ii].app_client_data;
				if (m->subscribed) {
					astat = m->stats.active_index?0:1; 
					hr = 0.0;
					if ((m->stats.last_swap_ms > 0) && (m->stats.diff_accepted[astat] > 0)) {
						hr = ((double)m->stats.diff_accepted[astat] / (double)((double)m->stats.last_swap_ms/1000.0)) * 0.004294967296; 
					}
					if (((double)(tsms - m->stats.last_swap_tsms)/1000.0) < 180.0) {
						thr += hr;
					}
				}
			}
		}
	}
	return thr;
}

void datum_stratum_v1_socket_thread_client_closed(T_DATUM_CLIENT_DATA *c, const char *msg) {
	DLOG_DEBUG("Stratum client connection closed. (%s)", msg);
}

void datum_stratum_v1_socket_thread_client_new(T_DATUM_CLIENT_DATA *c) {
	T_DATUM_MINER_DATA * const m = c->app_client_data;
	DLOG_DEBUG("New Stratum client connected. %d",c->fd);
	memset(m, 0, sizeof(T_DATUM_MINER_DATA));
	m->sdata = (T_DATUM_STRATUM_THREADPOOL_DATA *)c->datum_thread->app_thread_data;
	m->stats.last_swap_tsms = m->stats.last_share_tsms;
	m->best_share_diff = 0.0;
	static uint64_t unique_id_ctr = 0;
	m->unique_id = unique_id_ctr++;
	if (m->sdata->loop_tsms > 0) {
		m->connect_tsms = m->sdata->loop_tsms;
	} else {
		m->connect_tsms = current_time_millis();
	}
}

void datum_stratum_v1_socket_thread_init(T_DATUM_THREAD_DATA *my) {
	T_DATUM_STRATUM_THREADPOOL_DATA *sdata = (T_DATUM_STRATUM_THREADPOOL_DATA *)my->app_thread_data;
	pthread_rwlock_rdlock(&stratum_global_job_ptr_lock);
	sdata->latest_stratum_job_index = global_latest_stratum_job_index;
	sdata->cur_stratum_job = global_cur_stratum_jobs[global_latest_stratum_job_index];
	pthread_rwlock_unlock(&stratum_global_job_ptr_lock);
	sdata->new_job = false;
	sdata->last_sent_job_state = 0;
	sdata->next_kick_check_tsms = current_time_millis() + 10000;
	datum_stratum_dupes_init(sdata);
}

int datum_stratum_v1_get_thread_subscriber_count(T_DATUM_THREAD_DATA *my) {
	int i,c=0;
	T_DATUM_MINER_DATA *m;
	for(i=0;i<my->app->max_clients_thread;i++) {
		m = my->client_data[i].app_client_data;
		if (my->client_data[i].fd && m->subscribed) {
			c++;
		}
	}
	return c;
}

bool stratum_job_coinbaser_ready(T_DATUM_STRATUM_THREADPOOL_DATA *sdata, T_DATUM_STRATUM_JOB *job) {
	bool a = false;
	if ((sdata->loop_tsms > job->tsms) && (sdata->loop_tsms - job->tsms) > 5000) {
		sdata->full_coinbase_ready = false;
		return true;
	}
	pthread_rwlock_rdlock(&need_coinbaser_rwlocks[job->global_index]);
	if (!job->need_coinbaser) {
		a = true;
	}
	pthread_rwlock_unlock(&need_coinbaser_rwlocks[job->global_index]);
	if (a) {
		sdata->full_coinbase_ready = true;
	}
	return a;
}

void datum_stratum_v1_socket_thread_loop(T_DATUM_THREAD_DATA *my) {
	T_DATUM_STRATUM_THREADPOOL_DATA *sdata = (T_DATUM_STRATUM_THREADPOOL_DATA *)my->app_thread_data;
	T_DATUM_STRATUM_JOB *job = NULL;
	T_DATUM_MINER_DATA *m = NULL;
	int i, cnt = 0;
	bool change_ready = true;
	uint64_t tsms,tsms2,tsms3;
	
	pthread_rwlock_rdlock(&stratum_global_job_ptr_lock);
	if (global_latest_stratum_job_index != sdata->latest_stratum_job_index) {
		change_ready = true;
		if ((sdata->last_was_empty) && (global_cur_stratum_jobs[global_latest_stratum_job_index]->job_state >= JOB_STATE_FULL_PRIORITY_WAIT_COINBASER)) {
			if (!stratum_job_coinbaser_ready(sdata,global_cur_stratum_jobs[global_latest_stratum_job_index])) {
				if (sdata->last_job_height == global_cur_stratum_jobs[global_latest_stratum_job_index]->height) {
					change_ready = false;
				}
			}
		}
		if (change_ready) {
			sdata->cur_stratum_job = global_cur_stratum_jobs[global_latest_stratum_job_index];
			sdata->latest_stratum_job_index = global_latest_stratum_job_index;
			sdata->new_job = true;
			if (sdata->cur_stratum_job->job_state == 2) {
				sdata->last_was_empty = false;
			}
			sdata->notify_remaining_count = 0;
			sdata->full_coinbase_ready = false;
			sdata->last_job_height = sdata->cur_stratum_job->height;
		}
	}
	pthread_rwlock_unlock(&stratum_global_job_ptr_lock);
	
	sdata->loop_tsms = current_time_millis();
	job = sdata->cur_stratum_job;
	
	if (sdata->new_job) {
		switch (job->job_state) {
			case 1: {
				sdata->full_coinbase_ready = false;
				for(i=0;i<my->app->max_clients_thread;i++) {
					m = my->client_data[i].app_client_data;
					if (my->client_data[i].fd && m->subscribed) {
						send_mining_notify(&my->client_data[i],true,false,true);
						cnt++;
					}
				}
				sdata->new_job = false;
				sdata->last_was_empty = true;
				stratum_latest_empty_increment_complete(sdata->latest_stratum_job_index, cnt);
				sdata->last_sent_job_state = 1;
				break;
			}
			case 2: {
				sdata->full_coinbase_ready = false;
				if (!sdata->last_was_empty) {
					for(i=0;i<my->app->max_clients_thread;i++) {
						m = my->client_data[i].app_client_data;
						if (my->client_data[i].fd && m->subscribed) {
							send_mining_notify(&my->client_data[i],true,false,true);
							cnt++;
						}
					}
					sdata->last_was_empty = true;
					stratum_latest_empty_increment_complete(sdata->latest_stratum_job_index, cnt);
					sdata->last_sent_job_state = 2;
				} else {
					if (stratum_latest_empty_check_ready_for_full()) {
						for(i=0;i<my->app->max_clients_thread;i++) {
							m = my->client_data[i].app_client_data;
							if (my->client_data[i].fd && m->subscribed) {
								send_mining_notify(&my->client_data[i],false,false,false);
							}
						}
						sdata->new_job = false;
						sdata->last_was_empty = false;
						sdata->last_sent_job_state = 2;
					}
				}
				break;
			}
			case 3: {
				sdata->full_coinbase_ready = false;
				for(i=0;i<my->app->max_clients_thread;i++) {
					m = my->client_data[i].app_client_data;
					if (my->client_data[i].fd && m->subscribed) {
						send_mining_notify(&my->client_data[i],false,false,false);
					}
				}
				sdata->new_job = false;
				sdata->last_was_empty = false;
				sdata->last_sent_job_state = 3;
				break;
			}
			case 4: {
				sdata->full_coinbase_ready = false;
				if (stratum_job_coinbaser_ready(sdata,job)) {
					for(i=0;i<my->app->max_clients_thread;i++) {
						m = my->client_data[i].app_client_data;
						if (my->client_data[i].fd && m->subscribed) {
							send_mining_notify(&my->client_data[i],false,false,false);
						}
					}
					sdata->new_job = false;
					sdata->last_was_empty = false;
					sdata->last_sent_job_state = 4;
				}
				break;
			}
			case 5: {
				sdata->full_coinbase_ready = false;
				if (stratum_job_coinbaser_ready(sdata,job)) {
					if (sdata->last_was_empty) {
						for(i=0;i<my->app->max_clients_thread;i++) {
							m = my->client_data[i].app_client_data;
							if (my->client_data[i].fd && m->subscribed) {
								send_mining_notify(&my->client_data[i],false,false,false);
							}
						}
					} else {
						sdata->notify_remaining_count = datum_stratum_v1_get_thread_subscriber_count(my);
						if (sdata->notify_remaining_count > 0) {
							sdata->notify_last_cid = -1;
							sdata->notify_start_time = sdata->loop_tsms;
							sdata->notify_delay_per_slot_tsms = ((datum_config.bitcoind_work_update_seconds - 3)*1000) / sdata->notify_remaining_count;
							if (!sdata->notify_delay_per_slot_tsms) sdata->notify_delay_per_slot_tsms = 1;
							sdata->notify_last_time = sdata->loop_tsms - ((sdata->notify_delay_per_slot_tsms / my->app->max_threads) * my->thread_id);
						}
					}
					sdata->new_job = false;
					sdata->last_was_empty = false;
					sdata->last_sent_job_state = 5;
				}
				break;
			}
			default: break;
		}
	}
	
	if (sdata->notify_remaining_count > 0) {
		tsms = sdata->loop_tsms - sdata->notify_last_time;
		if ((!tsms) || (tsms >= sdata->notify_delay_per_slot_tsms)) {
			tsms = tsms / sdata->notify_delay_per_slot_tsms;
			if (!tsms) tsms = 1;
			for(i=(sdata->notify_last_cid+1);i<my->app->max_clients_thread;i++) {
				m = my->client_data[i].app_client_data;
				if (my->client_data[i].fd && m->subscribed && m->subscribe_tsms <= sdata->notify_start_time) {
					send_mining_notify(&my->client_data[i],false,false,false);
					sdata->notify_remaining_count--;
					sdata->notify_last_cid = i;
					tsms--;
					if (!tsms) break;
				}
			}
			if (i==my->app->max_clients_thread) {
				sdata->notify_remaining_count = 0;
			}
			sdata->notify_last_time = sdata->loop_tsms;
		}
	}
	
	if (sdata->loop_tsms >= sdata->next_kick_check_tsms) {
		if ((datum_config.stratum_v1_idle_timeout_no_subscribe > 0) || (datum_config.stratum_v1_idle_timeout_no_share > 0) || (datum_config.stratum_v1_idle_timeout_max_last_work)) {
			tsms = 1; tsms2 = 1; tsms3 = 1;
			if (datum_config.stratum_v1_idle_timeout_no_subscribe > 0) tsms = sdata->loop_tsms - (datum_config.stratum_v1_idle_timeout_no_subscribe * 1000);
			if (datum_config.stratum_v1_idle_timeout_no_share > 0) tsms2 = sdata->loop_tsms - (datum_config.stratum_v1_idle_timeout_no_share * 1000);
			if (datum_config.stratum_v1_idle_timeout_max_last_work > 0) tsms3 = sdata->loop_tsms - (datum_config.stratum_v1_idle_timeout_max_last_work * 1000);
			
			for(i=0;i<my->app->max_clients_thread;i++) {
				if (my->client_data[i].fd) {
					m = my->client_data[i].app_client_data;
					if (m->subscribed) {
						if (m->share_count_accepted > 0) {
							if (m->stats.last_share_tsms < tsms3) {
								my->client_data[i].kill_request = true;
								my->has_client_kill_request = true;
							}
						} else {
							if (m->connect_tsms < tsms2) {
								my->client_data[i].kill_request = true;
								my->has_client_kill_request = true;
							}
						}
					} else {
						if (m->connect_tsms < tsms) {
							my->client_data[i].kill_request = true;
							my->has_client_kill_request = true;
						}
					}
				}
			}
		}
		sdata->next_kick_check_tsms = sdata->loop_tsms + 11150;
	}
}

void send_error_to_client(T_DATUM_CLIENT_DATA *c, uint64_t id, char *e) {
	char s[1024];
	snprintf(s, sizeof(s), "{\"error\":%s,\"id\":%"PRIu64",\"result\":null}\n", e, id);
	datum_socket_send_string_to_client(c, s);
}

static inline void send_unknown_work_error(T_DATUM_CLIENT_DATA *c, uint64_t id) { send_error_to_client(c, id, "[20,\"unknown-work\",null]"); }
static inline void send_rejected_high_hash_error(T_DATUM_CLIENT_DATA *c, uint64_t id) { send_error_to_client(c, id, "[23,\"high-hash\",null]"); }
static inline void send_rejected_stale(T_DATUM_CLIENT_DATA *c, uint64_t id) { send_error_to_client(c, id, "[21,\"stale-work\",null]"); }
static inline void send_rejected_time_too_old(T_DATUM_CLIENT_DATA *c, uint64_t id) { send_error_to_client(c, id, "[21,\"time-too-old\",null]"); }
static inline void send_rejected_time_too_new(T_DATUM_CLIENT_DATA *c, uint64_t id) { send_error_to_client(c, id, "[21,\"time-too-new\",null]"); }
static inline void send_rejected_stale_block(T_DATUM_CLIENT_DATA *c, uint64_t id) { send_error_to_client(c, id, "[21,\"stale-prevblk\",null]"); }
static inline void send_rejected_hnotzero_error(T_DATUM_CLIENT_DATA *c, uint64_t id) { send_error_to_client(c, id, "[23,\"H-not-zero\",null]"); }
static inline void send_bad_version_error(T_DATUM_CLIENT_DATA *c, uint64_t id) { send_error_to_client(c, id, "[23,\"bad-version\",null]"); }
static inline void send_rejected_duplicate(T_DATUM_CLIENT_DATA *c, uint64_t id) { send_error_to_client(c, id, "[22,\"duplicate\",null]"); }

uint32_t get_new_session_id(T_DATUM_CLIENT_DATA *c) {
	uint32_t i;
	i = ((uint32_t)c->cid) & (uint32_t)0x003FFFFF;
	i |= ((((uint32_t)c->datum_thread->thread_id)<<22) & (uint32_t)0xFFC00000);
	return i ^ 0xB10CF00D;
}

void reset_vardiff_stats(T_DATUM_CLIENT_DATA *c) {
	T_DATUM_MINER_DATA * const m = c->app_client_data;
	m->share_count_since_snap = 0;
	m->share_diff_since_snap = 0;
	m->share_snap_tsms = m->sdata->loop_tsms;
}

void stratum_update_vardiff(T_DATUM_CLIENT_DATA *c, bool no_quick) {
	T_DATUM_MINER_DATA * const m = c->app_client_data;
	uint64_t delta_tsms;
	uint64_t ms_per_share;
	uint64_t target_ms_share;
	
	if (m->current_diff != m->last_sent_diff) return;
	if ((!no_quick) && (m->share_count_since_snap < datum_config.stratum_v1_vardiff_quickdiff_count)) {
		return;
	}
	
	delta_tsms = m->sdata->loop_tsms - m->share_snap_tsms;
	
	if (!m->share_count_since_snap) {
		if (delta_tsms > 60000) {
			m->current_diff = m->current_diff >> 1;
			if (m->current_diff < m->forced_high_min_diff) m->current_diff = m->forced_high_min_diff;
			if (m->current_diff < datum_config.stratum_v1_vardiff_min) m->current_diff = datum_config.stratum_v1_vardiff_min;
			reset_vardiff_stats(c);
		}
		return;
	}
	
	if (delta_tsms < 1000) return;
	
	ms_per_share = delta_tsms / m->share_count_since_snap;
	if (!ms_per_share) ms_per_share = 1;
	target_ms_share = (uint64_t)60000/(uint64_t)datum_config.stratum_v1_vardiff_target_shares_min;
	
	if ((!m->quickdiff_active) && (!no_quick) && (ms_per_share < (target_ms_share/(uint64_t)datum_config.stratum_v1_vardiff_quickdiff_delta))) {
		delta_tsms = roundDownToPowerOfTwo_64((target_ms_share / ms_per_share) * m->current_diff);
		if (delta_tsms < (m->current_diff << 2)) delta_tsms = (m->current_diff << 2);
		m->current_diff = delta_tsms;
		send_mining_notify(c, true, true, false);
		reset_vardiff_stats(c);
		return;
	}
	
	if (ms_per_share > (target_ms_share*2)) {
		m->current_diff = m->current_diff >> 1;
		if (m->current_diff < m->forced_high_min_diff) m->current_diff = m->forced_high_min_diff;
		if (m->current_diff < datum_config.stratum_v1_vardiff_min) m->current_diff = datum_config.stratum_v1_vardiff_min;
		reset_vardiff_stats(c);
		return;
	}
	
	if (m->share_count_since_snap < 16) return;
	
	if (ms_per_share < (target_ms_share/2)) {
		m->current_diff = m->current_diff << 1;
		reset_vardiff_stats(c);
		return;
	}
	return;
}

#define STAT_CYCLE_MS 60000

void stratum_update_miner_stats_accepted(T_DATUM_CLIENT_DATA *c, uint64_t diff_accepted) {
	T_DATUM_MINER_DATA * const m = c->app_client_data;
	m->stats.diff_accepted[m->stats.active_index?1:0] += diff_accepted;
	m->stats.last_share_tsms = m->sdata->loop_tsms;
	
	if (m->sdata->loop_tsms >= (m->stats.last_swap_tsms+STAT_CYCLE_MS)) {
		m->stats.last_swap_ms = m->sdata->loop_tsms - m->stats.last_swap_tsms;
		m->stats.last_swap_tsms = m->sdata->loop_tsms;
		if (m->stats.active_index) {
			m->stats.active_index = 0;
			m->stats.diff_accepted[0] = 0;
		} else {
			m->stats.active_index = 1;
			m->stats.diff_accepted[1] = 0;
		}
	}
}

// ------------------------------------------------------------
// 通过 256位 Hash 计算真实难度的辅助函数
// ------------------------------------------------------------
static double get_share_actual_diff(const unsigned char *share_hash) {
	double h_val = 0.0;
	int k;
	// share_hash 是以 Little-Endian 存储的 256 位无符号整数
	// 按照算法，将其转换为双精度浮点数
	for (k = 31; k >= 0; k--) {
		h_val = h_val * 256.0 + share_hash[k];
	}
	if (h_val <= 0.0) return 999999999999999.0;
	// 26959946667150639794667015087019630673637144422540572481103610249216.0 
	// 是 Difficulty 1 对应的最大目标值 (0x00000000FFFF000000...)
	return 26959946667150639794667015087019630673637144422540572481103610249216.0 / h_val;
}

int client_mining_submit(T_DATUM_CLIENT_DATA *c, uint64_t id, json_t *params_obj) {
	json_t *job_id, *extranonce2, *ntime, *nonce, *vroll;
	T_DATUM_STRATUM_JOB *job = NULL;
	const char *job_id_s, *vroll_s, *extranonce2_s, *ntime_s, *nonce_s;
	uint32_t vroll_uint, bver, ntime_val, nonce_val;
	uint16_t g_job_index;
	unsigned char coinbase_index = 0;
	T_DATUM_STRATUM_COINBASE *cb = NULL;
	unsigned char extranonce_bin[12], block_header[80], digest_temp[40], share_hash[40], full_cb_txn[MAX_COINBASE_TXN_SIZE_BYTES];
	T_DATUM_MINER_DATA * const m = c->app_client_data;
	int i;
	bool quickdiff = false, empty_work = false, was_block = false;
	char new_notify_blockhash[65];
	
	job_id = json_array_get(params_obj, 1);
	if (!job_id || !(job_id_s = json_string_value(job_id))) {
		send_unknown_work_error(c,id);
		m->share_count_rejected++; m->share_diff_rejected+=m->last_sent_diff;
		return 0;
	}
	
	if (strlen(job_id_s) != 16) {
		if ((strlen(job_id_s) == 17) && (job_id_s[0] == 'Q')) {
			job_id_s++; quickdiff = true;
		} else if ((strlen(job_id_s) == 17) && (job_id_s[0] == 'N')) {
			job_id_s++; empty_work = true;
		} else {
			send_unknown_work_error(c,id);
			m->share_count_rejected++; m->share_diff_rejected+=m->last_sent_diff;
			return 0;
		}
	}
	
	g_job_index = (hex2bin_uchar(&job_id_s[0xA])<<8) | hex2bin_uchar(&job_id_s[0xC]);
	g_job_index ^= STRATUM_JOB_INDEX_XOR;
	if (g_job_index >= MAX_STRATUM_JOBS || !(job = global_cur_stratum_jobs[g_job_index])) {
		send_unknown_work_error(c,id);
		m->share_count_rejected++; m->share_diff_rejected+=m->last_sent_diff;
		return 0;
	}
	
	if (upk_u64le(job->job_id, 0) != upk_u64le(job_id_s, 0)) {
		send_unknown_work_error(c,id);
		m->share_count_rejected++; m->share_diff_rejected+=m->last_sent_diff;
		return 0;
	}
	
	const uint64_t job_diff = quickdiff ? m->quickdiff_value : m->stratum_job_diffs[g_job_index];
	bver = job->version_uint;
	
	if (m->extension_version_rolling) {
		vroll = json_array_get(params_obj, 5);
		if (!vroll || !(vroll_s = json_string_value(vroll))) {
			send_bad_version_error(c,id);
			m->share_count_rejected++; m->share_diff_rejected += job_diff;
			return 0;
		}
		vroll_uint = strtoul(vroll_s, NULL, 16);
		if ((vroll_uint & m->extension_version_rolling_mask) != vroll_uint) {
			send_bad_version_error(c,id);
			m->share_count_rejected++; m->share_diff_rejected += job_diff;
			return 0;
		}
		bver |= vroll_uint;
	}
	
	pk_u32le(block_header, 0, bver);
	memcpy(&block_header[4], job->prevhash_bin, 32);
	pk_u32le(extranonce_bin, 0, m->sid_inv);
	
	extranonce2 = json_array_get(params_obj, 2);
	if (!extranonce2 || !(extranonce2_s = json_string_value(extranonce2)) || strlen(extranonce2_s) != 16) {
		send_unknown_work_error(c, id);
		m->share_count_rejected++; m->share_diff_rejected += job_diff;
		return 0;
	}
	for(i=0;i<8;i++) extranonce_bin[i+4] = hex2bin_uchar(&extranonce2_s[i<<1]);
	
	coinbase_index = hex2bin_uchar(&job_id_s[0xE]);
	if (coinbase_index >= MAX_COINBASE_TYPES && !(empty_work && coinbase_index == 255)) {
		send_unknown_work_error(c, id);
		m->share_count_rejected++; m->share_diff_rejected += job_diff;
		return 0;
	}
	
	cb = empty_work ? &job->subsidy_only_coinbase : &job->coinbase[coinbase_index];
	if (!cb) {
		send_unknown_work_error(c, id);
		m->share_count_rejected++; m->share_diff_rejected += job_diff;
		return 0;
	}
	
	memcpy(&full_cb_txn[0], cb->coinb1_bin, cb->coinb1_len);
	memcpy(&full_cb_txn[cb->coinb1_len], extranonce_bin, 12);
	memcpy(&full_cb_txn[cb->coinb1_len+12], cb->coinb2_bin, cb->coinb2_len);
	
	if (quickdiff) {
		if (upk_u16le(full_cb_txn, cb->coinb1_len - 2) != 0x5144) pk_u16le(full_cb_txn, cb->coinb1_len - 2, 0x5144);
		else pk_u16le(full_cb_txn, cb->coinb1_len - 2, 0xAEBB);
		full_cb_txn[job->target_pot_index] = floorPoT(m->quickdiff_value);
	} else {
		full_cb_txn[job->target_pot_index] = floorPoT(m->stratum_job_diffs[g_job_index]);
	}
	
	if ((job->merklebranch_count) && (!empty_work)) {
		double_sha256(digest_temp, full_cb_txn, cb->coinb1_len+12+cb->coinb2_len);
		stratum_job_merkle_root_calc(job, digest_temp, &block_header[36]);
	} else {
		double_sha256(&block_header[36], full_cb_txn, cb->coinb1_len+12+cb->coinb2_len);
	}
	
	ntime = json_array_get(params_obj, 3);
	if (!ntime || !(ntime_s = json_string_value(ntime))) {
		send_unknown_work_error(c, id);
		m->share_count_rejected++; m->share_diff_rejected += job_diff;
		return 0;
	}
	ntime_val = strtoul(ntime_s, NULL, 16);
	pk_u32le(block_header, 68, ntime_val);
	memcpy(&block_header[72], &job->nbits_bin[0], sizeof(uint32_t));
	
	nonce = json_array_get(params_obj, 4);
	if (!nonce || !(nonce_s = json_string_value(nonce))) {
		send_unknown_work_error(c, id);
		m->share_count_rejected++; m->share_diff_rejected += job_diff;
		return 0;
	}
	nonce_val = strtoul(nonce_s, NULL, 16);
	pk_u32le(block_header, 76, nonce_val);
	
	my_sha256(digest_temp, block_header, 80);
	my_sha256(share_hash, digest_temp, 32);
	
	if (upk_u32le(share_hash, 28) != 0) {
		send_rejected_hnotzero_error(c, id);
		m->share_count_rejected++; m->share_diff_rejected += job_diff;
		return 0;
	}
	
	// Check if block found!
	if (compare_hashes(share_hash, job->block_target) <= 0) {
		was_block = true;
		new_notify_blockhash[64] = 0;
		for(i=0;i<32;i++) uchar_to_hex((char *)&new_notify_blockhash[(31-i)<<1], share_hash[i]);
		
		DLOG_WARN("************************************************************************************************");
		DLOG_WARN("******** SOLO BLOCK FOUND - %s ********",new_notify_blockhash);
		DLOG_WARN("************************************************************************************************");
		
		i = assembleBlockAndSubmit(block_header, full_cb_txn, cb->coinb1_len+12+cb->coinb2_len, job, m->sdata, new_notify_blockhash, empty_work);
		if (i) {
			datum_blocktemplates_notifynew(new_notify_blockhash, job->height + 1);
		}
	}
	
	if (job->is_stale_prevblock) {
		send_rejected_stale_block(c, id);
		m->share_count_rejected++; m->share_diff_rejected += job_diff;
		return 0;
	}
	
	if (ntime_val < job->block_template->mintime) {
		send_rejected_time_too_old(c, id);
		m->share_count_rejected++; m->share_diff_rejected += job_diff;
		return 0;
	}
	
	if (ntime_val > (job->block_template->curtime + 7200)) {
		send_rejected_time_too_new(c, id);
		m->share_count_rejected++; m->share_diff_rejected += job_diff;
		return 0;
	}
	
	if (!quickdiff) {
		if (compare_hashes(share_hash, m->stratum_job_targets[g_job_index]) > 0) {
			send_rejected_high_hash_error(c, id);
			m->share_count_rejected++; m->share_diff_rejected += job_diff;
			return 0;
		}
	} else {
		if (compare_hashes(share_hash, m->quickdiff_target) > 0) {
			send_rejected_high_hash_error(c, id);
			m->share_count_rejected++; m->share_diff_rejected += job_diff;
			return 0;
		}
	}
	
	if (m->sdata->loop_tsms > (job->tsms + ((datum_config.stratum_v1_share_stale_seconds + datum_config.bitcoind_work_update_seconds) * 1000))) {
		send_rejected_stale(c, id);
		m->share_count_rejected++; m->share_diff_rejected += job_diff;
		return 0;
	}
	
	if (datum_stratum_check_for_dupe(m->sdata, nonce_val, g_job_index, quickdiff?(~ntime_val):(ntime_val), bver, &extranonce_bin[0])) {
		send_rejected_duplicate(c, id);
		m->share_count_rejected++; m->share_diff_rejected += job_diff;
		return 0;
	}
	
	// ---> 这里修改为计算实际难度并比较更新 <---
	double actual_diff = get_share_actual_diff(share_hash);
	if (actual_diff > m->best_share_diff) {
		m->best_share_diff = actual_diff;
	}
	
	// work accepted (Locally, for vardiff and stats. No external forwarding!)
	char s[256];
	snprintf(s, sizeof(s), "{\"error\":null,\"id\":%"PRIu64",\"result\":true}\n", id);
	datum_socket_send_string_to_client(c, s);
	
	m->share_diff_accepted += job_diff;
	m->share_count_accepted++;
	m->share_count_since_snap++;
	m->share_diff_since_snap += job_diff;
	
	stratum_update_miner_stats_accepted(c, job_diff);
	stratum_update_vardiff(c,false);
	
	return 0;
}

int client_mining_configure(T_DATUM_CLIENT_DATA *c, uint64_t id, json_t *params_obj) {
	json_t *p1, *p2, *t;
	const char *s, *s2;
	char sx[1024]; char sa[1024];
	int sxl = 0, i;
	sx[0] = 0;
	T_DATUM_MINER_DATA * const m = c->app_client_data;
	bool new_vroll = false, new_mdiff = false;
	
	if (!json_is_array(params_obj)) return -1;
	p1 = json_array_get(params_obj, 0); p2 = json_array_get(params_obj, 1);
	if ((!p1) || (!p2)) return -1;
	
	size_t index; json_t *value;
	json_array_foreach(p1, index, value) {
		if (json_is_string(value)) {
			s = json_string_value(value);
			switch(s[0]) {
				case 'v': {
					if (!strcmp("version-rolling", s)) {
						new_vroll = true; m->extension_version_rolling = true;
						m->extension_version_rolling_mask = 0x1fffe000; m->extension_version_rolling_bits = 16;
						t = json_object_get(p2, "version-rolling.mask");
						if (t && (s2 = json_string_value(t))) m->extension_version_rolling_mask = strtoul(s2, NULL, 16) & m->extension_version_rolling_mask;
						sxl = sprintf(&sx[sxl], "{\"id\":null,\"method\":\"mining.set_version_mask\",\"params\":[\"%08x\"]}\n", m->extension_version_rolling_mask);
					}
					break;
				}
				case 'm': {
					if (!strcmp("minimum-difficulty", s)) new_mdiff = true;
					break;
				}
				default: break;
			}
		}
	}
	
	i = snprintf(sa, sizeof(sa), "{\"error\":null,\"id\":%"PRIu64",\"result\":{", id);
	if (new_vroll) i+= snprintf(&sa[i], sizeof(sa)-i, "\"version-rolling\":true,\"version-rolling.mask\":\"%08x\"", m->extension_version_rolling_mask);
	if (new_mdiff) i+= snprintf(&sa[i], sizeof(sa)-i, ",\"minimum-difficulty\":false");
	i+= snprintf(&sa[i], sizeof(sa)-i, "}}\n");
	
	datum_socket_send_string_to_client(c, sa);
	if (sxl) datum_socket_send_string_to_client(c, sx);
	return 0;
}

int client_mining_authorize(T_DATUM_CLIENT_DATA *c, uint64_t id, json_t *params_obj) {
	char s[256];
	const char *username_s;
	json_t *username;
	T_DATUM_MINER_DATA * const m = c->app_client_data;
	
	username = json_array_get(params_obj, 0);
	username_s = (username && json_string_value(username)) ? json_string_value(username) : "NULL";
	
	strncpy(m->last_auth_username, username_s, sizeof(m->last_auth_username) - 1);
	m->last_auth_username[sizeof(m->last_auth_username)-1] = 0;
	snprintf(s, sizeof(s), "{\"error\":null,\"id\":%"PRIu64",\"result\":true}\n", id);
	datum_socket_send_string_to_client(c, s);
	m->authorized = true;
	return 0;
}

int send_mining_notify(T_DATUM_CLIENT_DATA *c, bool clean, bool quickdiff, bool new_block) {
	T_DATUM_THREAD_DATA *t = (T_DATUM_THREAD_DATA *)c->datum_thread;
	T_DATUM_STRATUM_JOB *j = ((T_DATUM_STRATUM_THREADPOOL_DATA *)t->app_thread_data)->cur_stratum_job;
	T_DATUM_MINER_DATA * const m = c->app_client_data;
	T_DATUM_STRATUM_COINBASE *cb;
	char cb1[STRATUM_COINBASE1_MAX_LEN+2];
	unsigned int cbselect = 0;
	bool full_coinbase = false;
	char s[512];
	unsigned char tdiff = 0xFF;
	
	if (!j) return -1;
	
	if (new_block) quickdiff = false;
	if (!quickdiff) stratum_update_vardiff(c, true);
	
	if (m->last_sent_diff != m->current_diff) send_mining_set_difficulty(c);
	
	if (!quickdiff) {
		get_target_from_diff(m->stratum_job_targets[j->global_index], m->last_sent_diff);
		m->stratum_job_diffs[j->global_index] = m->last_sent_diff;
		m->quickdiff_active = false;
	} else {
		m->quickdiff_active = true;
		m->quickdiff_value = m->last_sent_diff;
		get_target_from_diff(m->quickdiff_target, m->quickdiff_value);
	}
	
	datum_socket_send_string_to_client(c, "{\"id\":null,\"method\":\"mining.notify\",\"params\":[");
	
	if (j->job_state >= JOB_STATE_FULL_PRIORITY_WAIT_COINBASER) {
		if (((T_DATUM_STRATUM_THREADPOOL_DATA *)t->app_thread_data)->full_coinbase_ready) full_coinbase = true;
	}
	
	cbselect = (new_block) ? 0 : (full_coinbase ? m->coinbase_selection : 0);
	cb = &j->coinbase[cbselect];
	
	if (quickdiff) {
		snprintf(s, sizeof(s), "\"Q%s%2.2x\",\"%s\",\"", j->job_id, cbselect, j->prevhash);
	} else {
		if (!new_block) {
			snprintf(s, sizeof(s), "\"%s%2.2x\",\"%s\",\"", j->job_id, cbselect, j->prevhash);
		} else {
			snprintf(s, sizeof(s), "\"N%s%2.2x\",\"%s\",\"", j->job_id, (unsigned int)255, j->prevhash);
			cb = &j->subsidy_only_coinbase;
		}
	}
	
	datum_socket_send_string_to_client(c, s);
	memcpy(cb1, cb->coinb1, cb->coinb1_len<<1);
	cb1[cb->coinb1_len<<1] = 0;
	
	tdiff = floorPoT(m->last_sent_diff);
	uchar_to_hex(&cb1[j->target_pot_index<<1], tdiff);
	
	if (quickdiff) {
		datum_socket_send_chars_to_client(c, cb1, (cb->coinb1_len<<1)-4);
		if (upk_u16le(cb->coinb1_bin, cb->coinb1_len - 2) != 0x5144) datum_socket_send_string_to_client(c, "4451");
		else datum_socket_send_string_to_client(c, "BBAE");
	} else {
		datum_socket_send_string_to_client(c, cb1);
	}
	
	datum_socket_send_string_to_client(c, "\",\"");
	datum_socket_send_string_to_client(c, cb->coinb2);
	datum_socket_send_string_to_client(c, "\",");
	
	if (!new_block) datum_socket_send_string_to_client(c, j->merklebranches_full);
	else datum_socket_send_string_to_client(c, "[]");
	
	snprintf(s, sizeof(s), ",\"%s\",\"%s\",\"%s\",", j->version, j->nbits, j->ntime);
	datum_socket_send_string_to_client(c, s);
	
	if ((clean) || (quickdiff) || (new_block)) datum_socket_send_string_to_client(c, "true]}\n");
	else datum_socket_send_string_to_client(c, "false]}\n");
	
	m->last_sent_stratum_job_index = j->global_index;
	return 0;
}

int send_mining_set_difficulty(T_DATUM_CLIENT_DATA *c) {
	char s[256];
	T_DATUM_MINER_DATA * const m = c->app_client_data;
	if (!m->current_diff) m->current_diff = datum_config.stratum_v1_vardiff_min;
	snprintf(s, sizeof(s), "{\"id\":null,\"method\":\"mining.set_difficulty\",\"params\":[%"PRIu64"]}\n", (uint64_t)m->current_diff);
	datum_socket_send_string_to_client(c, s);
	m->last_sent_diff = m->current_diff;
	return 0;
}

void datum_stratum_fingerprint_by_UA(T_DATUM_MINER_DATA *m) {
	if (strstr(m->useragent, "NiceHash/") == m->useragent) {
		m->current_diff = 524288; 
		m->forced_high_min_diff = 524288; 
		return;
	}
}

int client_mining_subscribe(T_DATUM_CLIENT_DATA *c, uint64_t id, json_t *params_obj) {
	uint32_t sid; char s[1024];
	T_DATUM_MINER_DATA * const m = c->app_client_data;
	json_t *useragent;
	
	if (m->subscribed) return 0;
	m->current_diff = datum_config.stratum_v1_vardiff_min;
	m->coinbase_selection = 0;
	m->useragent[0] = 0;
	
	if (params_obj && json_is_array(params_obj)) {
		useragent = json_array_get(params_obj, 0);
		if (json_is_string(useragent)) {
			strncpy_uachars(m->useragent, json_string_value(useragent), 127);
			m->useragent[127] = 0;
		}
	}
	
	if ((datum_config.stratum_v1_fingerprint_miners) && (m->useragent[0])) {
		datum_stratum_fingerprint_by_UA(m);
		if (m->current_diff < datum_config.stratum_v1_vardiff_min) m->current_diff = datum_config.stratum_v1_vardiff_min;
	}
	
	sid = get_new_session_id(c);
	m->sid = sid;
	m->sid_inv = ((sid>>24)&0xff) | (((sid>>16)&0xff)<<8) | (((sid>>8)&0xff)<<16) | ((sid&0xff)<<24);
	
	snprintf(s, sizeof(s), "{\"error\":null,\"id\":%"PRIu64",\"result\":[[[\"mining.notify\",\"%8.8x1\"],[\"mining.set_difficulty\",\"%8.8x2\"]],\"%8.8x\",8]}\n", id, sid, sid, sid);
	datum_socket_send_string_to_client(c, s);
	send_mining_set_difficulty(c);
	m->subscribed = true;
	send_mining_notify(c,true,false,false);
	
	m->share_count_since_snap = 0; m->share_diff_since_snap = 0;
	m->share_snap_tsms = m->sdata->loop_tsms; m->subscribe_tsms = m->sdata->loop_tsms;
	return 0;
}

int datum_stratum_v1_socket_thread_client_cmd(T_DATUM_CLIENT_DATA *c, char *line) {
	json_t *j ,*method_obj, *id_obj, *params_obj;
	json_error_t err = { };
	const char *method; int i; uint64_t id;
	
	if (line[0] == 0) return 0;
	if (line[0] != '{') return -1;
	
	j = json_loads(line, JSON_REJECT_DUPLICATES, &err);
	if (!j) return -2;
	if (!(method_obj = json_object_get(j, "method"))) { json_decref(j); return -3; }
	if (!json_is_string(method_obj)) { json_decref(j); return -6; }
	if (!(id_obj = json_object_get(j, "id")) || !json_is_integer(id_obj)) { json_decref(j); return -4; }
	id = json_integer_value(id_obj);
	if (!(params_obj = json_object_get(j, "params"))) { json_decref(j); return -5; }
	
	method = json_string_value(method_obj);
	if (method[0] == 0) { json_decref(j); return -7; }
	
	switch (method[0]) {
		case 'm': {
			if (!strcmp(method, "mining.submit")) { i = client_mining_submit(c, id, params_obj); json_decref(j); return i; }
			if (!strcmp(method, "mining.configure")) { i = client_mining_configure(c, id, params_obj); json_decref(j); return i; }
			if (!strcmp(method, "mining.subscribe")) { i = client_mining_subscribe(c, id, params_obj); json_decref(j); return i; }
			if (!strcmp(method, "mining.authorize")) { i = client_mining_authorize(c, id, params_obj); json_decref(j); return i; }
			[[fallthrough]];
		}
		default: {
			send_error_to_client(c, id, "[-3,\"Method not found\",null]");
			json_decref(j); return 0;
		}
	}
}

void stratum_job_merkle_root_calc(T_DATUM_STRATUM_JOB *s, unsigned char *coinbase_txn_hash, unsigned char *merkle_root_output) {
	int i; unsigned char combined[64]; unsigned char next[32];
	if (!s->merklebranch_count) { memcpy(merkle_root_output, coinbase_txn_hash, 32); return; }
	
	memcpy(&combined[0], coinbase_txn_hash, 32); memcpy(&combined[32], s->merklebranches_bin[0], 32);
	double_sha256(next, combined, 64);
	for(i=1;i<s->merklebranch_count;i++) {
		memcpy(&combined[0], next, 32); memcpy(&combined[32], s->merklebranches_bin[i], 32);
		double_sha256(next, combined, 64);
	}
	memcpy(merkle_root_output, next, 32);
	return;
}

void stratum_calculate_merkle_branches(T_DATUM_STRATUM_JOB *s) {
	bool level_needs_dupe = false; int current_level_size = 0, next_level_size = 0, q, i, j;
	unsigned char combined[64];
	const unsigned char (*current_level)[32]; unsigned char (*next_level)[32];
	static unsigned char templist[16384][32];
	static int safety_check; int marker = ++safety_check;
	
	if (s->block_template->txn_count > 16383) {
		panic_from_thread(__LINE__); return;
	}
	if (!s->block_template->txn_count) {
		s->merklebranch_count = 0; s->merklebranches_full[0] = '['; s->merklebranches_full[1] = ']'; s->merklebranches_full[2] = 0;
		return;
	}
	
	current_level_size = s->block_template->txn_count+1;
	next_level = &templist[0]; current_level = next_level;
	level_needs_dupe = false; q = 0;
	
	while (current_level_size > 1) {
		if (current_level_size % 2 != 0) { current_level_size++; level_needs_dupe = true; }
		else level_needs_dupe = false;
		
		next_level_size = current_level_size >> 1;
		for(i=0;i<next_level_size;i++) {
			if (!i) {
				if (!q) {
					memcpy(s->merklebranches_bin[0], s->block_template->txns[0].txid_bin, 32);
					for(j=0;j<32;j++) pk_u16le(s->merklebranches_hex[0], j << 1, upk_u16le(s->block_template->txns[0].txid_hex, (31 - j) << 1));
					s->merklebranches_hex[0][64] = 0;
				} else {
					if (level_needs_dupe && (i==(next_level_size-1))) memcpy(s->merklebranches_bin[q], &current_level[i<<1][0], 32);
					else memcpy(s->merklebranches_bin[q], &current_level[(i<<1)+1][0], 32);
					hash2hex(s->merklebranches_bin[q], s->merklebranches_hex[q]);
				}
			} else {
				if (!q) {
					memcpy(&combined[0], s->block_template->txns[(i<<1)-1].txid_bin, 32);
					if (level_needs_dupe && (i==(next_level_size-1))) memcpy(&combined[32], s->block_template->txns[(i<<1)-1].txid_bin, 32);
					else memcpy(&combined[32], s->block_template->txns[(i<<1)].txid_bin, 32);
				} else {
					memcpy(&combined[0], &current_level[i<<1][0], 32);
					if (level_needs_dupe && (i==(next_level_size-1))) memcpy(&combined[32], &current_level[i<<1][0], 32);
					else memcpy(&combined[32], &current_level[(i<<1)+1][0], 32);
				}
				double_sha256(next_level[i], combined, 64);
			}
		}
		current_level = next_level; next_level+=i+1;
		current_level_size = next_level_size; q++;
	}
	s->merklebranch_count = q;
	
	s->merklebranches_full[0] = '['; j=1;
	for(i=0;i<q;i++) {
		if (i) { s->merklebranches_full[j] = ','; j++; }
		j += sprintf(&s->merklebranches_full[j], "\"%s\"", s->merklebranches_hex[i]);
	}
	s->merklebranches_full[j] = ']'; s->merklebranches_full[j+1] = 0;
	if (safety_check != marker) panic_from_thread(__LINE__);
}

void update_stratum_job(T_DATUM_TEMPLATE_DATA *block_template, bool new_block, int job_state) {
	T_DATUM_STRATUM_JOB *s = &stratum_job_list[stratum_job_next]; int i;
	memset(s, 0, sizeof(T_DATUM_STRATUM_JOB));
	
	s->enprefix = stratum_enprefix ^ 0xB10C; stratum_enprefix++;
	for(i=0;i<8;i++) pk_u64le(s->prevhash, i << 3, upk_u64le(block_template->previousblockhash, (7 - i) << 3));
	s->prevhash[64] = 0;
	
	snprintf(s->version, sizeof(s->version), "%8.8x", block_template->version);
	s->version_uint = block_template->version;
	strncpy(s->nbits, block_template->bits, sizeof(s->nbits) - 1);
	snprintf(s->ntime, sizeof(s->ntime), "%8.8llx", (unsigned long long)block_template->curtime);
	
	s->coinbase_value = block_template->coinbasevalue;
	s->height = block_template->height; s->block_template = block_template;
	memcpy(s->prevhash_bin, block_template->previousblockhash_bin, 32);
	memcpy(s->nbits_bin, block_template->bits_bin, 4);
	s->nbits_uint = upk_u32le(s->nbits_bin, 0);
	nbits_to_target(s->nbits_uint, s->block_target);
	
	s->is_new_block = new_block; s->is_stale_prevblock = false;
	
	generate_base_coinbase_txns_for_stratum_job(s, s->is_new_block);
	s->job_state = job_state;
	if ((job_state == JOB_STATE_FULL_PRIORITY_WAIT_COINBASER) || (job_state == JOB_STATE_FULL_NORMAL_WAIT_COINBASER)) s->need_coinbaser = true;
	else s->need_coinbaser = false;
	
	if (new_block) {
		for(i=0;i<MAX_STRATUM_JOBS;i++) {
			if (i != stratum_job_next) stratum_job_list[i].is_stale_prevblock = true;
		}
	}
	
	stratum_job_next++;
	if (stratum_job_next == MAX_STRATUM_JOBS) stratum_job_next = 0;
	s->tsms = current_time_millis();
	stratum_calculate_merkle_branches(s);
	
	if (new_block) {
		pthread_rwlock_wrlock(&stratum_global_latest_empty_stat);
		stratum_latest_empty_complete_count = 0;
		stratum_latest_empty_ready_for_full = false;
		stratum_latest_empty_sent_count = 0;
		stratum_latest_empty_job_index = global_latest_stratum_job_index+1;
		if (stratum_latest_empty_job_index == MAX_STRATUM_JOBS) stratum_latest_empty_job_index = 0;
		pthread_rwlock_unlock(&stratum_global_latest_empty_stat);
	}
	
	pthread_rwlock_wrlock(&stratum_global_job_ptr_lock);
	global_latest_stratum_job_index++;
	if (global_latest_stratum_job_index == MAX_STRATUM_JOBS) global_latest_stratum_job_index = 0;
	
	s->global_index = global_latest_stratum_job_index;
	snprintf(s->job_id, sizeof(s->job_id), "%8.8x%2.2x%4.4x", (uint32_t)time(NULL), (uint8_t)stratum_job_next, (unsigned int)((uint16_t)s->global_index ^ STRATUM_JOB_INDEX_XOR));
	
	global_cur_stratum_jobs[global_latest_stratum_job_index] = s;
	pthread_rwlock_unlock(&stratum_global_job_ptr_lock);
	DLOG_DEBUG("Updated to job %d, ncb = %d, state = %d", s->global_index, s->need_coinbaser?1:0, s->job_state);
	return;
}

int assembleBlockAndSubmit(uint8_t *block_header, uint8_t *coinbase_txn, size_t coinbase_txn_size, T_DATUM_STRATUM_JOB *job, T_DATUM_STRATUM_THREADPOOL_DATA *sdata, const char *block_hash_hex, bool empty_work) {
	char *submitblock_req = NULL, *ptr = NULL, *s = NULL;
	size_t i; json_t *r; CURL *tcurl; int ret = 0; bool free_submitblock_req = false;
	
	submitblock_req = sdata->submitblock_req;
	if (!submitblock_req) {
		submitblock_req = malloc(8500000); 
		if (!submitblock_req) { panic_from_thread(__LINE__); return 0; }
		free_submitblock_req = true;
	}
	
	ptr = submitblock_req;
	ptr += sprintf(ptr, "{\"jsonrpc\":\"1.0\",\"id\":\"%llu\",\"method\":\"submitblock\",\"params\":[\"",(unsigned long long)time(NULL));
	for(i=0;i<80;i++) ptr += sprintf(ptr, "%2.2x", block_header[i]);
	
	if (!empty_work) ptr += append_bitcoin_varint_hex(job->block_template->txn_count + 1, ptr);
	else ptr += append_bitcoin_varint_hex(1, ptr);
	
	for(i=0;i<coinbase_txn_size;i++) ptr += sprintf(ptr, "%2.2x", coinbase_txn[i]);
	
	if (!empty_work) {
		for(i=0;i<job->block_template->txn_count;i++) {
			memcpy(ptr, job->block_template->txns[i].txn_data_hex, job->block_template->txns[i].size*2);
			ptr += job->block_template->txns[i].size*2;
		}
	}
	
	*ptr = '"'; ptr++; *ptr = ']'; ptr++; *ptr = '}'; ptr++; *ptr = 0;
	datum_submitblock_trigger(submitblock_req, block_hash_hex);
	
	if (datum_config.mining_save_submitblocks_dir[0] != 0) {
		char submitblockpath[384];
		if (snprintf(submitblockpath, sizeof(submitblockpath), "%s/datum_submitblock_%s.json", datum_config.mining_save_submitblocks_dir, block_hash_hex) < sizeof(submitblockpath)) {
			FILE *f = fopen(submitblockpath, "w");
			if (f) { fwrite(submitblock_req, ptr-submitblock_req, 1, f); fclose(f); }
		}
	}
	
	if (!(tcurl = curl_easy_init())) return 0;
	r = bitcoind_json_rpc_call(tcurl, &datum_config, submitblock_req);
	curl_easy_cleanup(tcurl);
	
	if (!r) {
		DLOG_INFO("Block %s submitted to upstream node successfully!",block_hash_hex); ret = 1;
	} else {
		s = json_dumps(r, JSON_ENCODE_ANY);
		if (s) { DLOG_WARN("Upstream node rejected our block! (%s)",s); free(s); }
		json_decref(r); ret = 0;
	}
	
	if (free_submitblock_req) {
		usleep(10000); datum_submitblock_waitfree(); free(submitblock_req);
	}
	return ret;
}

char* datum_stratum_get_workers_json(void) {
	json_t *root = json_array();
	if (!global_stratum_app) return json_dumps(root, JSON_COMPACT);
	
	int i, ii;
	uint64_t tsms = current_time_millis();
	
	for(i = 0; i < global_stratum_app->max_threads; i++) {
		for(ii = 0; ii < global_stratum_app->max_clients_thread; ii++) {
			if (global_stratum_app->datum_threads[i].client_data[ii].fd > 0) {
				T_DATUM_MINER_DATA *m = global_stratum_app->datum_threads[i].client_data[ii].app_client_data;
				if (m && m->subscribed) {
					json_t *worker = json_object();
					
					// 隐私：不再发送 name (last_auth_username)
					json_object_set_new(worker, "user_agent", json_string(m->useragent[0] ? m->useragent : "Unknown"));
					json_object_set_new(worker, "best_diff", json_real(m->best_share_diff));
					
					double hr = 0.0;
					unsigned char astat = m->stats.active_index ? 0 : 1;
					if ((m->stats.last_swap_ms > 0) && (m->stats.diff_accepted[astat] > 0)) {
						hr = ((double)m->stats.diff_accepted[astat] / (double)((double)m->stats.last_swap_ms / 1000.0)) * 0.004294967296;
					}
					// 超过 180 秒无提交视为掉线 (算力归零)
					if (((double)(tsms - m->stats.last_swap_tsms) / 1000.0) >= 180.0) {
						hr = 0.0; 
					}
					json_object_set_new(worker, "hashrate", json_real(hr));
					
					json_array_append_new(root, worker);
				}
			}
		}
	}
	char *json_str = json_dumps(root, JSON_COMPACT);
	json_decref(root);
	return json_str;
}
